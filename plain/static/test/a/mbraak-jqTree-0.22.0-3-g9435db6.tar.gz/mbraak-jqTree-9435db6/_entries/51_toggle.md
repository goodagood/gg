---
title: toggle
name: functions-toggle
---

**function toggle(node);**

Open or close the tree node.
