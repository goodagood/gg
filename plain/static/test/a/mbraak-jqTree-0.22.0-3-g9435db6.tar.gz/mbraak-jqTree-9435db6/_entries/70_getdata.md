---
title: getData
name: node-functions-getdata
---

Get the subtree of this node.

{% highlight js %}
var data = node.getData();
{% endhighlight %}
