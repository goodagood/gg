---
title: Introduction
name: introduction
---

JqTree is a jQuery widget for displaying a **tree structure** in html. It supports **json data**, loading via
**ajax** and **drag-and-drop**.

[![Bower version](https://badge.fury.io/bo/jqtree.svg)](http://badge.fury.io/bo/jqtree)
