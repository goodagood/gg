---
title: Requirements
name: requirements
---

* [jQuery](http://jquery.com) 1.5+ or 2.0
