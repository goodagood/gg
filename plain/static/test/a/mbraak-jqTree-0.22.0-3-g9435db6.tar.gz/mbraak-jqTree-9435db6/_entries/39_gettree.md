---
title: getTree
name: functions-gettree
---

**function getTree();**

Get the root node of the tree.
